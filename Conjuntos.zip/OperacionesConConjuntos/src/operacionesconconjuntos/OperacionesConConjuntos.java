
package operacionesconconjuntos;

import java.util.Scanner;

public class OperacionesConConjuntos {
    public static void main(String[] args) {
        
        
        Scanner palabra = new Scanner (System.in);
		Scanner stri = new Scanner (System.in);
		
		Operaciones obj = new Operaciones();
		int x = 0;
		int O=0;
		String U = " ";
		
		System.out.println("¿Cuantos conjuntos desea?\n(Minimo 2 maximo 5)");
		x= palabra.nextInt();
		if(x>5){
			System.out.println("Solo se pueden introducir minimo 2 o maximo 5 conjuntos\nVuelva a escribir el número de conjuntos: ");
			x= palabra.nextInt();
		}
		System.out.println("");
		
		obj.metodos(x);
		System.out.println("");
	
		 while(O!=5)
		    {
			 System.out.println("¿Qué operación decea hacer?");
			 System.out.println("1.Unión\n2.Intersección\n3.Resta\n4.Complemento\n5.Cerrar programa");
			 System.out.println("Escriba el número de la opción que desea: ");
		    O=palabra.nextInt();
		    
		      
		   switch(O)
		   {
		       case 1:System.out.println("Los conjuntos los debe escribir en mayuscula: ");
		    	   System.out.println("Unio se pone una U mayuscula entre los conjuntos.\nEjemplo: AUB, EUA.");
		       U= stri.nextLine();
				obj.Union(U);
		       ;break;
		    	   
		       case 2:System.out.println("Los conjuntos los debe escribir en mayuscula: ");
		    	   System.out.println("Intersección se pone una n minuscula entre los conjuntos.\nEjemplo: CnE, DnB");
		       U= stri.nextLine();
		       obj.Interseccion(U);
		       ;break;
		    	   
		       case 3:System.out.println("Los conjuntos los debe escribir en mayuscula: ");
		    	   System.out.println("Resta se pone el signo - entre los conjuntos.\nEjemplo: E-B, C-E.");
		       U= stri.nextLine();
		       obj.Resta(U);
		       ;break;
		    	   
		       case 4:System.out.println("Los conjuntos los debe escribir en mayuscula: ");
		    	   System.out.println("Complemento se pone una c minuscula despues del conjunto.\nEjemplo Ac, Cc.");
		       U= stri.nextLine();  
		       obj.complemento(U);
		       ;break;
		     
		   }
		

		}
                 
                 
        
    }


    
}
